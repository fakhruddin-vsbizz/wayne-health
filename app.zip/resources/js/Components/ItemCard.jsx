import React from "react";
import { Link } from "react-router-dom";
import { primaryGreen, primaryYellow } from "../constantVriables";

const ItemCard = ({
    name,
    starts_at,
    productId,
    img,
    manufacturer,
    item_code,
}) => {
    // console.log(img);
    return (
        <div
            style={{ border: `1px ${primaryYellow} solid` }}
            class="w-56 bg-white shadow-md rounded-xl duration-500 hover:scale-105 hover:shadow-xl"
        >
            <Link to={`/customer/product/${productId}`}>
                <div class="w-full flex justify-center">
                    <img
                        src={`/images/${img}`}
                        alt="Product"
                        class="h-60 w-32 object-contain rounded-t-xl pt-1"
                    />
                </div>
                <div class="px-4 py-3 w-56 flex flex-col">
                    <span className="text-gray-500 text-xs">
                        {manufacturer}
                    </span>
                    <p class="text-xs font-bold text-black wrap block capitalize">
                        {name}
                    </p>
                    <p className="font-bold text-black wrap block capitalize text-xs">
                        {item_code}
                    </p>
                    <div class="flex items-center justify-between">
                        <span
                            style={{ color: primaryGreen }}
                            class="text-gray-400 mr-3 uppercase text-md font-bold text-xs"
                        >
                            Price Starts At:
                        </span>
                        <p
                            style={{ color: primaryGreen }}
                            class="text-xs text-black my-3 font-bold"
                        >
                            $ {starts_at}
                        </p>
                        {/* {{-- <div class="ml-auto"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                            fill="currentColor" class="bi bi-bag-plus" viewBox="0 0 16 16">
                            <path fill-rule="evenodd"
                                d="M8 7.5a.5.5 0 0 1 .5.5v1.5H10a.5.5 0 0 1 0 1H8.5V12a.5.5 0 0 1-1 0v-1.5H6a.5.5 0 0 1 0-1h1.5V8a.5.5 0 0 1 .5-.5z" />
                            <path
                                d="M8 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 8 1zm3.5 3v-.5a3.5 3.5 0 1 0-7 0V4H1v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V4h-3.5zM2 5h12v9a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V5z" />
                        </svg></div> --}} */}
                    </div>
                </div>
            </Link>
        </div>
    );
};

export default ItemCard;
