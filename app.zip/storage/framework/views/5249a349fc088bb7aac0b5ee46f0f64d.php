<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
</head>
<body>
    <?php echo $emailHtml; ?>


    <div className="mx-4 my-8 text-black">
    <hr className="border-black w-1/3 mb-4" />
    <p className="mb-3">
        Return Policy & Disclaimers: - Garments are not
        returnable.
    </p>
    <ul className="list-disc">
        <li className="ml-10">
            <p>
                Please make sure the size is correct, and all
                personalization information and spellings are
                checked prior to placing the order.
            </p>
        </li>
        <li className="ml-10">
            <p>
                Turn garments inside out and wash according to
                the manufacturer's laundering instructions. We
                are not responsible for incorrectly laundered
                garments.
            </p>
        </li>
    </ul>
    <hr className="border-black w-1/3 mt-4" />
</div>

    <p>Thank you again,</p>
    <p>www.upgmarket.com</p>
    

</body>
</html>
<?php /**PATH C:\projects\php\laravel-11\wayne-health-react\wayne-health-react\resources\views/order-confirmation.blade.php ENDPATH**/ ?>