<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Mail</title>
</head>
<body>
    <?php echo $emailHtml; ?>


    
    

</body>
</html><?php /**PATH C:\projects\php\laravel-11\wayne-health-react\wayne-health-react\resources\views/contact-mail.blade.php ENDPATH**/ ?>